import React from 'react'

export default function Contacto() {
  return (
    <div>Contacto mi primer SPA</div>
  )
}

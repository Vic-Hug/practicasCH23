import React from 'react'

function PrimerComponente() {
  return (
    <div>
            <h1>PrimerComponente</h1>
            <h2>días de la semana</h2>
            <ul>
            <li>Lunes</li>
            <li>Martes</li>
            <li>Miercoles</li>
            <li>Jueves</li>
            <li>Viernes</li>
            <li>Sabado</li>
            </ul>
    </div>
  )
}

export default PrimerComponente




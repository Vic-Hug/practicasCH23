package com.generation.cohorte23.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaOrmApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaOrmApplication.class, args);
	}

}

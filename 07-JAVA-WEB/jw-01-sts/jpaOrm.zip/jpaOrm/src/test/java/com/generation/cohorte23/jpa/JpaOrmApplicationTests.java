package com.generation.cohorte23.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaOrmApplicationTests {

	@Test
	void contextLoads() {
	}

}

INSERT INTO `tienda`.`cliente` (`nombre`, `apellido`, `telefono`, `email`, `ciudad`, `pais`) VALUES ('Pedro', 'Rojas', '', 'pedrorojas@test.com', 'Quebec', 'Canadá');
INSERT INTO `tienda`.`cliente` (`nombre`, `apellido`, `email`, `ciudad`, `pais`) VALUES ('Audrey', 'Mora', 'audreymora@test.com', 'Brucelas', 'Bélgica');
INSERT INTO `tienda`.`cliente` (`nombre`, `apellido`, `telefono`, `ciudad`, `pais`) VALUES ('Nancy', 'Monge', '(131)785823', 'Santigo', 'Chile');
